import { v4 as uuid } from 'uuid';
import { db } from '../database';


export const createNewListingRoute = {
    method: 'POST',
    path: '/api/listings',
    handler: async (req, h) => {
        const id = uuid();
        const { name = '', description = '', price = 0 } = req.payload;
        const user_id = '12345';
        const views = 0;

        await db.query(
            `INSERT into listings(id,name,description,price,user_id,views)
            VALUES(?,?,?,?,?,?)
            `, [id, name, description, price, user_id, views]
        )
        return { id, name, description, price, user_id, views }
    }
}